export { RaisedButton.RightIcon } from "./RaisedButton.RightIcon";
