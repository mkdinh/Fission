// Import React dependencies
//--------------------------------------------------------
import React, { Component } from "react";
import "./App.css";


// Create App component
//--------------------------------------------------------

class App extends Component {
	render(){
		return(

			<div>

				<a/>
				<a/>
				<action/>
				<a/>

			</div>
		)
	}
};

export { App };
